# Airline-Reservation-System

This is a simple and responsive Airline Reservation System with complete frotend as well as backend.

Languages-
1. HTML 
2. CSS 
3. Javascript 
4. PHP
5.  MYSQL

Attached below, are the screenshots of the Project's various functionalities
![Screenshot 2021-11-25 144406](https://user-images.githubusercontent.com/72501682/143414198-80457346-fc40-4fbe-8784-345f7837692e.jpg)
![Screenshot 2021-11-25 144452](https://user-images.githubusercontent.com/72501682/143414193-769d7ef6-6421-498d-b47a-787fd24cd6bb.jpg)
![Screenshot 2021-11-25 144547](https://user-images.githubusercontent.com/72501682/143414190-82908c41-e22a-4300-b77c-69aa24e1b656.jpg)
![Screenshot 2021-11-25 144621](https://user-images.githubusercontent.com/72501682/143414188-108dcfdf-252c-4e15-a3f4-8eb612551aa3.jpg)
![Screenshot 2021-11-25 144919](https://user-images.githubusercontent.com/72501682/143414186-d9ff37a3-7a29-4e76-b020-89d49a81524a.jpg)
![Screenshot 2021-11-25 144933](https://user-images.githubusercontent.com/72501682/143414183-c4135c7d-8748-4500-ae83-92ecd8aef813.jpg)
![Screenshot 2021-11-25 145002](https://user-images.githubusercontent.com/72501682/143414171-3f805ba3-b215-4462-aa71-b9d1b09152f8.jpg)

